using Microsoft.AspNetCore.Mvc;

namespace ipt.Controllers
{
    public class MexicoController : Controller
    {
        public IActionResult Mexico()
        {
            return View();
        }
    }
}
