using Microsoft.AspNetCore.Mvc;

namespace ipt.Controllers
{
    public class SpainController : Controller
    {
        public IActionResult Spain()
        {
            return View();
        }
    }
}
