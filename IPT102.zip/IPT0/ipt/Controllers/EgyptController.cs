using Microsoft.AspNetCore.Mvc;

namespace ipt.Controllers
{
    public class EgyptController : Controller
    {
        public IActionResult Egypt()
        {
            return View();
        }
    }
}
