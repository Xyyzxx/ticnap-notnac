using Microsoft.AspNetCore.Mvc;

namespace ipt.Controllers
{
    public class GermanyController : Controller
    {
        public IActionResult Germany()
        {
            return View();
        }
    }
}
